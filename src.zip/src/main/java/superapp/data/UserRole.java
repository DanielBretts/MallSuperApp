package superapp.data;

public enum UserRole {
	MINIAPP_USER, SUPERAPP_USER, ADMIN
}
